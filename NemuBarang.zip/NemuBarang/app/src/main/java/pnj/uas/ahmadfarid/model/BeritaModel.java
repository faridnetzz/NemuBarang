package pnj.uas.ahmadfarid.model;

public class BeritaModel {
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDeskrisi() {
        return Deskrisi;
    }

    public void setDeskrisi(String deskrisi) {
        Deskrisi = deskrisi;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    String title, Deskrisi, Image;
}
