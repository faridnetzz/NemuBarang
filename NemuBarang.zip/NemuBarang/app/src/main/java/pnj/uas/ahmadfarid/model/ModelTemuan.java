package pnj.uas.ahmadfarid.model;

public class ModelTemuan {
    String id;
    String tlp;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTlp() { return tlp; }

    public void setTlp(String Tlp) {this.tlp = tlp;}

    public String getBarang() { return barang;}

    public void setBarang(String barang) { this.barang = barang;}

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getwaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getWaktu() { return tgl; }

    public void setTgl(String tgl) { this.tgl = tgl;}

    public String getDeskripsi() { return deskripsi; }

    public void setDeskripsi(String deskripsi) {this.deskripsi = deskripsi; }

    String barang;
    String nama;
    String lokasi;
    String waktu;
    String tgl;
    String deskripsi;
}
