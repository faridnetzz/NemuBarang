package pnj.uas.ahmadfarid.utils;

public class Config {
    public static String _BASE_URL = "http://192.168.100.11/nemuinbarang/";
    public static String _LIST_TEMUAN = _BASE_URL+"tampilsemuapgw.php";
    public static String _DETAIL_PEGAWAI = _BASE_URL+"tampilpgw.php";
    public static String _UPDATE_PEGAWAI = _BASE_URL+"updatepgw.php";
    public static String _CREATE_PEGAWAI = _BASE_URL+"tambahpgw.php";
    public static String _DELETE_PEGAWAI = _BASE_URL+"hapuspgw.php";
    public static String _UPLOAD_IMAGE = _BASE_URL+"uploadimage.php";
    public static String _TAMBAH_IMAGE = _BASE_URL+"tambahimage.php";

}